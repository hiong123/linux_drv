#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'xy'

def add(x, y):
    return x + y

sum = lambda x, y: x + y
