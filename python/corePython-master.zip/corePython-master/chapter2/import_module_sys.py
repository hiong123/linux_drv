'''
edit by xy


'''

# -*- coding: utf-8 -*-

import sys

sys.stdout.write('Hello World!\n')

print sys.platform

print sys.version

