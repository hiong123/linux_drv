'''
edit by xy


'''

# -*- coding: utf-8 -*-

def add(x,y):
    'this string is correct'
    return int(x)+int(y)

print add(5,2)

