'''
edit by xy


'''

# -*- coding: utf-8 -*-

a = raw_input('input num:\n')
if a>0:
    print '+'

if a<0:
    print '-'
if a==0:
    print '0'


