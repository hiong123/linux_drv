'''
edit by xy


'''

# -*- coding: utf-8 -*-

subtot = 0
for i in range(5):
    subtot += int(raw_input('enter a num\n'))
print subtot


