'''
edit by xy


'''

# -*- coding: utf-8 -*-
i=0
while i<11:
    print i,
    i+=1
print
for i in range(11):
    print i,
