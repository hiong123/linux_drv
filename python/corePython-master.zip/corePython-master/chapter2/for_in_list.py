'''
edit by xy


'''

# -*- coding: utf-8 -*-

squared = [x**2 for x in range(4)]#列表解析，**表示乘方

for i in squared:
    print i,
