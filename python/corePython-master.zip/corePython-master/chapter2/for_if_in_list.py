'''
edit by xy


'''

# -*- coding: utf-8 -*-

sqdEvens = [x ** 2 for x in range(8) if not x % 2]

for i in sqdEvens:
    print i,
