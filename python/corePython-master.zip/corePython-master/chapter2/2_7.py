'''
edit by xy


'''

# -*- coding: utf-8 -*-

s=raw_input('input:\n')
i=len(s)
j=0
while j<i:
    print s[j],
    j+=1

print
for n in range(len(s)):
    print s[n],

print
