import sys

print 'you entered', len(sys.argv), 'arguments'
print 'they were: ', str(sys.argv)