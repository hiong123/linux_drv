#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'xy'

'''命令行参数。写一个程序，打印出所有的命令行参数。'''

import sys
for item in sys.argv:
    print item
