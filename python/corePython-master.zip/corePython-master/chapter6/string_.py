# -*- coding: utf-8 -*-
__author__ = 'xy'

import string

print string.uppercase
print string.lowercase
print string.letters
print string.digits
# ABCDEFGHIJKLMNOPQRSTUVWXYZ
# abcdefghijklmnopqrstuvwxyz
# abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ
# 0123456789

#这些东西用于判断输入类型（ACM题中有的）


