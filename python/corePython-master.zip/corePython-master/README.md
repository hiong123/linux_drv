# corePython

《Python 核心编程 第二版》 (《Core Python Programming 2nd Edition》)

包括学习笔记、事例代码以及课后练习的答案 自己写的=。= 

慢慢更新中

欢迎探讨学习
邮件至xyntax@163.com 秒回
